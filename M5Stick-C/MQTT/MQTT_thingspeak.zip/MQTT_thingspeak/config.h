// WiFi Credential
#define WIFI_SSID "Erufu"
#define WIFI_PASSWD "Delta_006"

// Thingspeak
#define MQTT_SERVER "mqtt3.thingspeak.com"
#define MQTT_CHANNEL "1850649"

#define SECRET_MQTT_USERNAME "KSkrBCgiEAA9AiMpDzwrExs"
#define SECRET_MQTT_CLIENT_ID "KSkrBCgiEAA9AiMpDzwrExs"
#define SECRET_MQTT_PASSWORD "eatO+tqAmxNVOVxv+byKi7Hy"
